#!/bin/sh
echo ciao
